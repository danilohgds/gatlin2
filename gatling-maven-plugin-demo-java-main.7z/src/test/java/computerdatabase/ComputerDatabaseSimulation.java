package computerdatabase;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.*;

import io.gatling.javaapi.core.*;
import io.gatling.javaapi.http.*;

import java.time.Duration;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Stream;

public class ComputerDatabaseSimulation extends Simulation {
//
//
//    public static void main(String[] args){
//
//    }
    // Define the HTTP protocol
    HttpProtocolBuilder httpProtocol = http
            .baseUrl("http://3.87.76.179:8080") // Base URL for the API
            .acceptHeader("application/json")
            .userAgentHeader("Gatling");

    // Define feeder to generate random longitude and latitude
    FeederBuilder<String> locationFeeder = csv("locations.csv").random(); // Use a CSV file for predefined values

    // If dynamic generation is preferred, use custom feeder
    Iterator<Map<String, Double>> randomLocationFeeder = Stream.generate(() -> {
        double longitude = ThreadLocalRandom.current().nextDouble(-180.0, 180.0);
        double latitude = ThreadLocalRandom.current().nextDouble(-90.0, 90.0);
        return Map.of("longitude", longitude, "latitude", latitude);
    }).iterator();

    // Define the scenario
    ScenarioBuilder scn = scenario("Check Car Location")
            .feed(locationFeeder) // Use CSV or random feeder
            .exec(
                    http("Check Car Location")
                            .get("/routes/6748cbffcce7e3a383072fc2/checkCarLocation")
                            .queryParam("longitude", "#{longitude}") // Use dynamic values from feeder
                            .queryParam("latitude", "#{latitude}") // Use dynamic values from feeder
                            .check(status().is(200)) // Validate response
            );

    {
        // Define the setup with a load model
        setUp(
                scn.injectOpen(constantUsersPerSec(1500).during(Duration.ofSeconds(300))) // 10 users over 20 seconds
        ).protocols(httpProtocol);
    }
}
